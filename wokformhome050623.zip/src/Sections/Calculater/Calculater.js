import React from 'react'
import "./Calculater.css"
const Calculater = () => {
  return (
    <div>Calculater</div>
  )
}

export default Calculater